//
//  APPRTCDependent.h
//  APPRTCDependent
//
//  Created by Bourbon on 2020/7/8.
//  Copyright © 2020 Bourbon. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for APPRTCDependent.
FOUNDATION_EXPORT double APPRTCDependentVersionNumber;

//! Project version string for APPRTCDependent.
FOUNDATION_EXPORT const unsigned char APPRTCDependentVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <APPRTCDependent/PublicHeader.h>


